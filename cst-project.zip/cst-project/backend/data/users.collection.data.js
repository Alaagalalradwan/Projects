export const usersCollectionData = [
  {
    id: 20903,
    name: 'John Doe',
    email: 'john@example.com',
    role: 'customer',
    password: 'Test1234',
    avatar: 'avatar.jpg',
  },
  {
    id: 20904,
    name: 'Taylor Doe',
    email: 'taylor@example.com',
    role: 'seller',
    password: 'Test1234',
    avatar: 'avatar.jpg',
  },
  {
    id: 20905,
    name: 'Sheldon Copper',
    email: 'sheldon@example.com',
    role: 'admin',
    password: 'Test1234',
    avatar: 'avatar.jpg',
  },
];
