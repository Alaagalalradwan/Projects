export const productCategoriesCollectionData = [
  {
    id: 10110,
    name: 'Computers & Tablets',
  },
  {
    id: 10111,
    name: 'Mobile & Accessories',
  },
  {
    id: 10112,
    name: 'TV & Home Theater',
  },
  {
    id: 10113,
    name: 'Audio & Headphones',
  },
  {
    id: 10114,
    name: 'Camera & Camcorders',
  },
  {
    id: 10115,
    name: 'Gaming Equipment',
  },
];
