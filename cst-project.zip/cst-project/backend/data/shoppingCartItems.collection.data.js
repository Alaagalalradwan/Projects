export const shoppingCartItemsCollectionData = [
  {
    id: 20500,
    cartId: 20403,
    productId: 10001,
    quantity: 1,
  },
  {
    id: 20501,
    cartId: 20403,
    productId: 10010,
    quantity: 2,
  },
  {
    id: 20502,
    cartId: 20403,
    productId: 10026,
    quantity: 3,
  },
];
