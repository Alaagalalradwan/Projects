export const shoppingCartsCollectionData = [
  {
    id: 20403,
    customerId: 20903,
  },
];
