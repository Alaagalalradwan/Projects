export const orderItemsCollectionData = [
  {
    id: 70010,
    orderId: 81102,
    productId: 10001,
    quantity: 2,
    totalPrice: 27000,
  },
  {
    id: 70011,
    orderId: 81102,
    productId: 10002,
    quantity: 3,
    totalPrice: 94455,
  },
  {
    id: 70012,
    orderId: 81102,
    productId: 10008,
    quantity: 1,
    totalPrice: 49050,
  },
  {
    id: 70013,
    orderId: 81102,
    productId: 10018,
    quantity: 1,
    totalPrice: 21450,
  },
];
